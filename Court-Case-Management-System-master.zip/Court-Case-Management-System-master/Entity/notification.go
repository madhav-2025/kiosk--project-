package entity

import "time"

//Notification struct
type NotificationTest struct {
	NotfDescription string
	NotfTitle       string
	NotfLevel       string
	NotfDate        time.Time
}
